using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace Banking.Logic
{
    public abstract class Account
    {
      public abstract string AccountNumber { get; set; }
      public abstract string AccountHolder { get; set;  }
      public abstract decimal CurrentBalance { get; set; }

      public abstract bool IsAllowed(Transaction t);

      public abstract bool TryExecute(Transaction t);
    }
}
