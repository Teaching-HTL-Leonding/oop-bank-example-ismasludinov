using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banking.Logic
{
  public class SavingAccounts : Account
  {
    public override string AccountHolder { get; set; }
    public override string AccountNumber { get; set; }
    public override decimal CurrentBalance { get; set; }

    public override bool IsAllowed(Transaction t)
    {
      if (CurrentBalance + t.Amount >= 0 && CurrentBalance + t.Amount <= 100000000)
      {
        return true;
      }
      return false;
     
    }
    public override bool TryExecute(Transaction t)
    {
      if (IsAllowed(t) == true)
      {
        CurrentBalance += t.Amount;
        return true;
 
      }
    
      return false;
    }
  }
}
