using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banking.Logic
{
  public class Transaction 
  {
    public Transaction(string? accountNumber, string? description, DateTime timestamp, decimal amount)
    {
      AccountNumber = accountNumber;
      Description = description;
      Timestamp = timestamp;
      Amount = amount;
    }
  
    public string? AccountNumber { get; set;  }

    public string? Description { get; set;  }

    public DateTime Timestamp { get; set;  }

    public decimal Amount { get; set; }
  }
}
