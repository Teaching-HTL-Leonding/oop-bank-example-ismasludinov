using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using Banking.Logic;

namespace Banking.App
{
    public class Program
    {
    public static void Main()
    {
      Console.WriteLine($"Type of account ([c]hecking, [b]usiness, [s]avings): ");
      var type = Console.ReadLine();

      Console.WriteLine($"Account number: ");
      var accountnumber = Console.ReadLine();

      Console.WriteLine($"Account Holder: ");
      var accountholder = Console.ReadLine();

      Console.WriteLine($"Current Balance: ");
      var currentbalance = Convert.ToDecimal(Console.ReadLine());

      Console.WriteLine("Transaction account number: ");
      var transactionAccountnumber = Console.ReadLine();

      Console.WriteLine("Transaction description: ");
      var description = Console.ReadLine();

      Console.WriteLine("Transaction amount: ");
      var amount = Convert.ToDecimal(Console.ReadLine());

      /*Console.WriteLine("Transaction timestamp: ");
      DateTime timestamp = Convert.ToDateTime(Console.ReadLine());*/
      DateTime timestamp = DateTime.Now;
      if (accountnumber == transactionAccountnumber)
      {
        switch (type.ToLower())
        {
          case "c":
            Account account = new CheckingAccount();
            var t = new Transaction(accountnumber, description, timestamp, amount);
            if (account.IsAllowed(t))
            {
              Console.WriteLine($"Transaction executed successfully. The new current balance is {account.CurrentBalance}€." ); 
            }
            else
            {
              Console.WriteLine($"Transaction not allowed");
            }
            break;
          case "b":
            account = new BusinessAcount();
            
            t = new Transaction(accountnumber, description, timestamp, amount);
            if (account.IsAllowed(t))
            {
              Console.WriteLine($"Transaction executed successfully. The new current balance is {account.CurrentBalance}€.");
            }
            else
            {
              Console.WriteLine($"Transaction not allowed");
            }
            break;
          case "s":
            account = new SavingAccounts();
            t = new Transaction(accountnumber, description, timestamp, amount);
            if (account.IsAllowed(t))
            {
              Console.WriteLine($"Transaction executed successfully. The new current balance is {account.CurrentBalance}€.");
            }
            else
            {
              Console.WriteLine($"Transaction not allowed");
            }
            break;
          default:
            Console.WriteLine($"([c]hecking, [b]usiness, [s]avings)!!!");
            break;
        }


      }
    } 

    }
}
